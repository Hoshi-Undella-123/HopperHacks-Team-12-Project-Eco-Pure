var firebaseConfig = {
    apiKey: "AIzaSyA1VhxyJhB0rfWYPlrfJ15Qi1Uy2VSwPk0",
    authDomain: "hopper-69d43.firebaseapp.com",
    projectId: "hopper-69d43",
    storageBucket: "hopper-69d43.appspot.com",
    messagingSenderId: "1061156430727",
    appId: "1:1061156430727:web:30564fd89b3de678d62922",
    measurementId: "G-BX88QJGWV0"
  };
  
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  
  const textEmail=document.getElementById('txtEmail')
  const textPassword=document.getElementById('txtPassword')
  const login=document.getElementById('login')
  const signup=document.getElementById('signup')
  const form=document.getElementById("signup-form")

  login.addEventListener('click',e => {
      const email=textEmail.value;
      const pass= textPassword.value;
      const auth=firebase.auth()
      console.log(email,pass)
      console.log(auth)
      
      const promise=auth.signInWithEmailAndPassword(email,pass)
      
      promise.catch(error =>{
          console.log(error.message);
          alert(error.message)
        })
  })
  signup.addEventListener('click',e => {
    const email=textEmail.value;
    const pass= textPassword.value;
    const auth=firebase.auth()
    console.log(email,pass)
    const promise=auth.createUserWithEmailAndPassword(email,pass)
    promise.catch(error =>{console.log(error.message)
        alert(error.message)})
    
    
})

firebase.auth().onAuthStateChanged(user => {
    if(user){
        console.log('logged in')
        window.location.href="profile.html"
   
    }
    else{
        console.log("not logged in")
    }
})
