
    var firebaseConfig = {
        apiKey: "AIzaSyA1VhxyJhB0rfWYPlrfJ15Qi1Uy2VSwPk0",
        authDomain: "hopper-69d43.firebaseapp.com",
        projectId: "hopper-69d43",
        storageBucket: "hopper-69d43.appspot.com",
        messagingSenderId: "1061156430727",
        appId: "1:1061156430727:web:30564fd89b3de678d62922",
        measurementId: "G-BX88QJGWV0"
      };
      
      // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
  
  firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
        var logout=document.getElementById("logout");
        console.log(firebase.auth().currentUser)
        console.log()
        document.getElementById("name").innerHTML=firebase.auth().currentUser.email;

        logout.addEventListener('click', e => {
            firebase.auth().signOut()
            window.location.href="index.html"


})
      // User is signed in.
    } else {
      // No user is signed in.
    }
  });


